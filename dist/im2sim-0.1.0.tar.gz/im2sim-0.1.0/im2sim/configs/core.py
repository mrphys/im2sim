# ==============================================================================
# Copyright 2026 University College London.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================


import json
from dataclasses import dataclass, field, fields
from enum import Enum
from types import UnionType
from typing import Any, ClassVar, TypeVar, Union, get_args, get_origin, get_type_hints

T = TypeVar("T", bound="Config")


@dataclass
class Config:
    """
    Base class for recursively serialisable configuration objects.

    This class provides recursive (de)serialization to/from dictionaries and JSON

    Subclasses should be defined as dataclasses.

    Example:

        .. code-block:: python

            cfg = MyConfig(...)
            cfg.save("config.json")
            cfg2 = MyConfig.load("config.json")
    """

    # Names of list fields that `__post_init__` stores in reverse of the order they are given in.
    # They are reversed back by `as_kwargs()` and `to_dict()` so that `mod()` and save/load
    # round-trip instead of reversing them again.
    _reversed_fields: ClassVar[tuple[str, ...]] = ()

    def __init_subclass__(cls):
        """Automatically initialise a preset registry for each subclass."""
        super().__init_subclass__()
        cls._presets = {}

    def mod(self, **kwargs):
        """
        Create a modified copy of the config with updated fields.

        Args:
            **kwargs: Field names and their new values.

        Returns:
            Config: A new config instance with updated fields.
        """
        return self.__class__(**{**self.as_kwargs(), **kwargs})

    def as_kwargs(self):
        """
        Convert config fields into keyword arguments.

        Returns:
            dict: Mapping of field names to values.
        """
        return {f.name: self._input_value(f.name) for f in fields(self)}

    def _input_value(self, name):
        """Return a field value in the order it is given to `__init__`."""
        value = getattr(self, name)
        if name in self._reversed_fields and isinstance(value, list):
            return list(reversed(value))
        return value

    def to_dict(self):
        """
        Recursively convert config into a serialisable dictionary.

        Returns:
            dict: Serialized representation."""
        return {
            "__class__": self.__class__.__name__,
            **{f.name: self._serialize_value(self._input_value(f.name)) for f in fields(self)},
        }

    @classmethod
    def from_dict(cls: type[T], data: dict[str, Any]) -> T:
        """
        Reconstruct a config object from a dictionary.

        Args:
            data: Serialized config dictionary.

        Returns:
            Reconstructed config object.
        """

        hints = get_type_hints(cls)

        kwargs = {}

        for f in fields(cls):
            if f.name not in data:
                continue

            value = data[f.name]
            field_type = hints.get(f.name)

            if field_type is not None:
                value = cls._deserialize_value(value, field_type)

            kwargs[f.name] = value

        return cls(**kwargs)

    @staticmethod
    def _serialize_value(value):
        """Recursively serialize values into JSON-compatible structures."""
        if isinstance(value, Config):
            return value.to_dict()

        if isinstance(value, Enum):
            return {
                "__enum__": value.__class__.__name__,
                "value": value.value,
            }

        if isinstance(value, list):
            return [Config._serialize_value(v) for v in value]

        if isinstance(value, dict):
            return {k: Config._serialize_value(v) for k, v in value.items()}

        return value

    @staticmethod
    def _deserialize_value(value, typ):
        """Recursively deserialize values based on type hints."""

        if value is None:
            return None

        origin = get_origin(typ)
        args = get_args(typ)

        # Optional[T] / T | None / Union[T, None]
        if origin in (Union, UnionType):
            for subtype in args:
                if subtype is type(None):
                    continue

                try:
                    return Config._deserialize_value(value, subtype)
                except (TypeError, ValueError):
                    continue

            return value

        # list[T]
        if origin is list:
            subtype = args[0]

            return [Config._deserialize_value(v, subtype) for v in value]

        # dict[K, V]
        if origin is dict:
            key_type, value_type = args

            return {
                Config._deserialize_key(k, key_type): Config._deserialize_value(v, value_type)
                for k, v in value.items()
            }

        # Nested Config
        if isinstance(typ, type) and issubclass(typ, Config):
            return typ.from_dict(value)

        # Enum (serialised as {"__enum__": name, "value": value})
        if isinstance(typ, type) and issubclass(typ, Enum):
            if isinstance(value, dict) and "__enum__" in value:
                value = value["value"]
            return typ(value)

        return value

    @staticmethod
    def _deserialize_key(key, typ):
        """JSON object keys are always strings, so cast them back to int / float / bool keys."""
        if isinstance(key, str) and typ in (int, float):
            return typ(key)
        if isinstance(key, str) and typ is bool:
            return key.lower() == "true"
        return Config._deserialize_value(key, typ)

    def save(self, filepath):
        """
        Save config to a JSON file.

        Args:
            filepath (str): Path to file.
        """
        with open(filepath, "w") as f:
            json.dump(self.to_dict(), f, indent=4)

    @classmethod
    def load(cls, filepath):
        """
        Load config from a JSON file.

        Args:
            filepath (str): Path to file.

        Returns:
            Config: Loaded config instance.
        """
        with open(filepath) as f:
            data = json.load(f)

        return cls.from_dict(data)


CONFIG_REGISTRY = {}


def register_config(cls):
    """
    Register a config class globally.
    Useful for dynamic lookup and deserialization.

    Args:
        cls (type): Config class.

    Returns:
        type: Registered class.
    """
    CONFIG_REGISTRY[cls.__name__] = cls
    return cls


@register_config
@dataclass
class LayerConfig(Config):
    """
    Configuration for a single layer/module.

    Args:
        name (str | None):
            The name of the layer/module. (e.g., 'Conv', 'Linear', 'BatchNorm', etc.). `None` creates an identity layer.

        kwargs (dict[str, Any]):
            A dictionary of keyword arguments for the layer/module. (e.g. {'kernel_size': 3, 'stride': 1, 'padding': 1})

    Examples:

        .. code-block:: python

            conv_cfg = LayerConfig(name='Conv', kwargs={'kernel_size': 3, 'stride': 1, 'padding': 1})
            batchnorm_cfg = LayerConfig(name='BatchNorm', kwargs={'affine': True})

    Note:
    If being used within an im2sim model, inferred inputs like `in_channels` and `out_channels` should not be included and
    will be automatically set based on the model's architecture.
    The rank will also be inferred from the model's architecture and should not be included in the configuration.

    """

    name: str
    kwargs: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        # Configs saved with an explicit ``null`` (or created with ``kwargs=None``) mean "no kwargs".
        if self.kwargs is None:
            self.kwargs = {}
