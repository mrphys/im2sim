# ==============================================================================
# Copyright 2026 University College London.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================


from copy import deepcopy
from dataclasses import dataclass, field

from im2sim.configs.core import Config, LayerConfig, register_config
from im2sim.configs.image_blocks import ImageConvBlockConfig


@register_config
@dataclass
class HalfUNetConfig(Config):
    """
    Configuration class for the HalfUNet model (see `im2sim.models.HalfUNet`).

    For features like serialisation and saving/loading see `im2sim.configs.core.Config`.

    Args:
        hidden_channels (int):
            Number of hidden channels in the HalfUNet. Default is `64`.

        n_levels (int):
            Number of levels in the HalfUNet. Default is `3`.

        pool_cfg (LayerConfig | list[LayerConfig]):
            Configuration for pooling layers. Can be a single LayerConfig or a list of LayerConfigs for each level starting with the highest resolution.
            Default is `MaxPool` with kernel size `2`.

        upsample_cfg (LayerConfig | list[LayerConfig]):
            Configuration for upsampling layers. Can be a single LayerConfig or a list of LayerConfigs for each level starting with the lowest resolution.
            Upsamples are applied sequentially from the lowest resolution to the highest resolution. So at each stage, the upsample should only increase the resolution to the next higher level.
            Default is `Upsample` with scale factor `2` and mode is adjusted based on rank (`bilinear` for 2D, `trilinear` for 3D).

        block_cfg (ImageConvBlockConfig):
            Configuration for convolutional blocks. Used as a default for encoder blocks.
            Default is `ImageConvBlockConfig()`: a single `3x3` convolution with `"same"` padding, `InstanceNorm` and `ReLU` activation.

        stem_block_cfg (ImageConvBlockConfig | None):
            Configuration for the stem block. Can only be a single ImageConvBlockConfig.
            If None, uses block_cfg reduced to a single layer with no dropout or residual connections (see `ImageConvBlockConfig.to_single_block()`).

        encoder_block_cfg (list[ImageConvBlockConfig] | ImageConvBlockConfig | None):
            Configuration for encoder blocks. Can be a single ImageConvBlockConfig or a list of ImageConvBlockConfigs for each level starting with the highest resolution.
            If None, uses block_cfg for all levels.

        out_block_cfg (ImageConvBlockConfig | None):
            Configuration for the output block. Can only be a single ImageConvBlockConfig.
            If None, uses a single `1x1` convolution taken from block_cfg with `out_activation` as its output activation.

        encoder_blocks_per_level (int):
             Number of convolutional blocks per level in the encoder. Default is `1`.

        fusion_type (str):
            Type of residual connection for skip connections. Options are `'add'` or `'concat'`. Default is `'add'`.

        out_activation (str | None):
            Activation function for the output block. If None, no activation is applied.
            Only used when `out_block_cfg` is None.

        enable_temporal (bool):
            If True, the temporal versions of the layers (see `im2sim.layers.temporal_layers`) are used, so the model accepts inputs of shape `(N, C, T, *spatial)` with the time axis after channels.
            Only supported for rank `2` and `3` and the layers Conv, ConvTranspose, MaxPool, AvgPool, BatchNorm, InstanceNorm, Upsample and Dropout;
            other layers (e.g. GhostConv or SqueezeExcite) raise an `UnsupportedTemporalLayerError`.
            A scalar conv `kernel_size`/`padding` also applies to time, while pooling, upsampling and strides only resample the spatial dims
            unless a `(T, *spatial)` tuple is given.
            Default is `False`.

    Examples:

        To create a customised configuration for a HalfUNet, you can create a preferred ImageConvBlockConfig and use it for the encoder blocks:

        .. code-block:: python

            block_cfg = ImageConvBlockConfig(
                depth=4,
                activation="LeakyReLU",
                out_activation="sigmoid",
                conv_cfg=LayerConfig(name="Conv", kwargs={"kernel_size": 5, "padding": "same"}),
                norm_cfg=LayerConfig(name="BatchNorm", kwargs={"affine": True}),
                dropout_cfg=LayerConfig(name="Dropout", kwargs={"p": 0.5}),
                attn_cfg=LayerConfig(name="SqueezeExcite", kwargs={}),
                dropout_position=[1, 3],
                residual_connections={3: [0, 1]},
                residual_type="concat"
            )
            cfg = HalfUNetConfig(
                hidden_channels=32,
                n_levels=4,
                pool_cfg=LayerConfig(name="MaxPool", kwargs={"kernel_size": 2}),
                upsample_cfg=LayerConfig(name="Upsample", kwargs={"scale_factor": 2, "mode": "bilinear"}),
                block_cfg=block_cfg)

        If you want more flexibility you can also specify different configurations for the encoder blocks:


        .. code-block:: python

            encoder_block_cfg = [
                ImageConvBlockConfig(depth=5, activation="GELU", out_activation="sigmoid"),
                ImageConvBlockConfig(depth=4, activation="ELU", out_activation="sigmoid"),
                ImageConvBlockConfig(depth=3, activation="LeakyReLU", out_activation="sigmoid"),
                ImageConvBlockConfig(depth=2, activation="ReLU", out_activation="sigmoid")
            ]
            cfg = HalfUNetConfig(
                hidden_channels=32,
                n_levels=4,
                encoder_block_cfg=encoder_block_cfg
            )

        Similarly, if you want to specify different configurations for the stem block and output block, you can do so:

        .. code-block:: python

            stem_cfg = ImageConvBlockConfig(depth=1, activation="ReLU", out_activation="sigmoid")
            out_block_cfg = ImageConvBlockConfig(depth=1, activation=None, out_activation="sigmoid")
            cfg = HalfUNetConfig(
                hidden_channels=32,
                n_levels=4,
                stem_block_cfg=stem_cfg,
                out_block_cfg=out_block_cfg
            )


        The `mod()` method can be especially useful for making simple modifications to the block configurations for different types of blocks.

        .. code-block:: python

            block_cfg = ImageConvBlockConfig(depth=3, activation="ReLU", out_activation="sigmoid")
            encoder_block_cfg = [block_cfg.mod(depth=4) for _ in range(4)]
            cfg = HalfUNetConfig(
                hidden_channels=32,
                n_levels=4,
                encoder_block_cfg=encoder_block_cfg
            )

        You can also use the `mod()` method to modify a HalfUNetConfig object directly, which will apply the modification to all blocks of that type:

        .. code-block:: python

            cfg = HalfUNetConfig(
                hidden_channels=32,
                n_levels=4,
                block_cfg=ImageConvBlockConfig(depth=3, activation="ReLU", out_activation="sigmoid")
            )
            cfg = cfg.mod(encoder_block_cfg=ImageConvBlockConfig(depth=4))

        For heterogeneous pooling and upsampling layers, you can specify a list of LayerConfig objects for each level:

        .. code-block:: python

            pool_cfg = [
                LayerConfig(name="MaxPool", kwargs={"kernel_size": (1,2)}),
                LayerConfig(name="AvgPool", kwargs={"kernel_size": 2}),
                LayerConfig(name="MaxPool", kwargs={"kernel_size": 2}),
            ]
            upsample_cfg = [
                LayerConfig(name="Upsample", kwargs={"scale_factor": 2, "mode": "bilinear"}),
                LayerConfig(name="Upsample", kwargs={"scale_factor": 2, "mode": "bilinear"}),
                LayerConfig(name="Upsample", kwargs={"scale_factor": (1,2), "mode": "bilinear"}),
            ]
            cfg = HalfUNetConfig(
                hidden_channels=32,
                n_levels=4,
                pool_cfg=pool_cfg,
                upsample_cfg=upsample_cfg
            )

        To make simple modifications to the default configuration, you can modify a subset of attributes:

        .. code-block:: python

            cfg = HalfUNetConfig(fusion_type='add', out_activation='sigmoid')


        Different presets exist to perform common transformations on the configuration.
        For example, to convert the convolutional blocks to use depthwise separable convolutions and add residual connections to the input of each block, you can do:

        .. code-block:: python

            cfg = HalfUNetConfig().to_depthwise_separable().add_residual()

        To save the configuration to a JSON file and load it back, you can use:

        .. code-block:: python

            cfg.save("my_config.json")
            loaded_cfg = HalfUNetConfig.load("my_config.json")

        Refer to the methods below to see all available transformations that can be applied to the configuration.
    """

    hidden_channels: int = 64

    n_levels: int = 3

    pool_cfg: LayerConfig | list[LayerConfig] = field(
        default_factory=lambda: LayerConfig(name="MaxPool", kwargs={"kernel_size": 2})
    )
    upsample_cfg: LayerConfig | list[LayerConfig] = field(
        default_factory=lambda: LayerConfig(
            name="Upsample", kwargs={"scale_factor": 2, "mode": "trilinear"}
        )
    )

    block_cfg: ImageConvBlockConfig = field(default_factory=lambda: ImageConvBlockConfig())

    stem_block_cfg: ImageConvBlockConfig | None = None
    encoder_block_cfg: list[ImageConvBlockConfig] | ImageConvBlockConfig | None = None

    out_block_cfg: ImageConvBlockConfig | None = None
    encoder_blocks_per_level: int = 1
    fusion_type: str = "add"
    out_activation: str | None = None
    enable_temporal: bool = False

    _reversed_fields = ("upsample_cfg",)

    def __post_init__(self):

        L = self.n_levels

        # stem block configs
        if self.stem_block_cfg is None:
            self.stem_block_cfg = deepcopy(self.block_cfg)
            self.stem_block_cfg = self.stem_block_cfg.to_single_block()

        # Encoder configs
        if self.encoder_block_cfg is None:
            self.encoder_block_cfg = [deepcopy(self.block_cfg) for _ in range(L)]
        elif isinstance(self.encoder_block_cfg, ImageConvBlockConfig):
            self.encoder_block_cfg = [deepcopy(self.encoder_block_cfg) for _ in range(L)]
        else:
            assert len(self.encoder_block_cfg) == L, (
                f"Length of encoder_block_cfg ({len(self.encoder_block_cfg)}) must be equal to number of levels ({L})"
            )

        if self.out_block_cfg is None:
            self.out_block_cfg = deepcopy(self.block_cfg).to_single_conv()
            self.out_block_cfg.conv_cfg.kwargs.update({"kernel_size": 1, "stride": 1, "padding": 0})
            self.out_block_cfg.out_activation = self.out_activation

        if isinstance(self.pool_cfg, LayerConfig):
            self.pool_cfg = [deepcopy(self.pool_cfg) for _ in range(L - 1)]
        else:
            assert len(self.pool_cfg) == L - 1, (
                f"Length of pool_cfg ({len(self.pool_cfg)}) must be equal to levels - 1 ({L - 1})"
            )

        if isinstance(self.upsample_cfg, LayerConfig):
            self.upsample_cfg = [deepcopy(self.upsample_cfg) for _ in range(L - 1)]
        else:
            assert len(self.upsample_cfg) == L - 1, (
                f"Length of upsample_cfg ({len(self.upsample_cfg)}) must be equal to levels - 1 ({L - 1})"
            )
        self.upsample_cfg = list(reversed(self.upsample_cfg))

    def add_residual(self):
        """
        Apply an input residual connection (see `ImageConvBlockConfig.add_input_residual()`) to all encoder blocks except the first (highest resolution) encoder block.

        The residual connection type is set to "add", so the input of each block is added to the output of the block.
        This can help with gradient flow and improve training stability.
        """

        for e in self.encoder_block_cfg[1:]:
            e.add_input_residual()

        return self

    def dilate_bottleneck(self, dilation: int = 2):
        """
        Apply dilated convolutions to the bottleneck (lowest resolution) block in the HalfUNet configuration.

        This change modifies the last encoder block to use dilated convolutions, which can help increase the receptive field without increasing the number of parameters.

        Args:
            dilation (int): the dilation rate to use for the convolutions in the bottleneck block. Default is 2.
        """
        self.encoder_block_cfg[-1] = self.encoder_block_cfg[-1].dilate_convs(dilation)
        return self

    def double_bottleneck(self):
        """
        Apply a double bottleneck configuration to the HalfUNet.

        This change modifies the last encoder block to double the depth (number of convolutional layers), which can help increase the capacity of the model.
        """
        self.encoder_block_cfg[-1].depth = self.encoder_block_cfg[-1].depth * 2
        return self

    def reconstruction_mode(self):
        """
        Apply a reconstruction preset to all blocks in the HalfUNet configuration.

        This preset is typically used for image reconstruction or superresolution tasks,
        where the output is expected to be a continuous value (e.g., pixel intensity).
        """
        self.stem_block_cfg = self.stem_block_cfg.reconstruction_mode()
        self.out_activation = None
        self.out_block_cfg.out_activation = None
        self.out_block_cfg = self.out_block_cfg.reconstruction_mode()
        for e in self.encoder_block_cfg:
            e = e.reconstruction_mode()
        return self

    def segmentation_mode(self):
        self.out_block_cfg.out_activation = None
        self.out_block_cfg = self.out_block_cfg.segmentation_mode()
        # The output block produces the logits: normalising them (per instance) forces a zero
        # mean logit map and prevents e.g. predicting an empty mask, so keep the norm off it.
        self.out_block_cfg.norm_cfg = LayerConfig(name=None, kwargs={})
        for e in self.encoder_block_cfg:
            e = e.segmentation_mode()
        return self

    def single_class_segmentation_mode(self):
        """
        Apply a single-class segmentation preset to all blocks in the HalfUNet configuration.

        Use this preset for binary segmentation tasks, where the output is expected to be a probability map for a single class.
        """
        self.segmentation_mode()
        self.out_activation = "sigmoid"
        self.out_block_cfg.out_activation = "sigmoid"
        return self

    def multiclass_segmentation_mode(self):
        """
        Apply a multi-class segmentation preset to all blocks in the HalfUNet configuration.

        Use this preset for multi-class segmentation tasks, where the output is expected to be a probability map for multiple classes.
        """
        self.segmentation_mode()
        self.out_activation = "softmax"
        self.out_block_cfg.out_activation = "softmax"
        return self

    def to_depthwise_separable(self):
        """
        Apply a depthwise separable convolution (see `im2sim.layers.DepthwiseSeparableConv`) preset to stem + all encoder blocks in the HalfUNet configuration.
        """
        self.stem_block_cfg.conv_cfg.name = "DepthwiseSeparableConv"
        for e in self.encoder_block_cfg:
            e.conv_cfg.name = "DepthwiseSeparableConv"
        return self

    def to_ghost_depthwise(self):
        """
        Apply a ghost depthwise convolution (see `im2sim.layers.GhostConv`) preset to stem + all encoder blocks in the HalfUNet configuration.
        """
        self.stem_block_cfg.conv_cfg.name = "GhostConv"
        for e in self.encoder_block_cfg:
            e.conv_cfg.name = "GhostConv"
        return self

    def to_ghost_depthwise_separable(self):
        """
        Apply a ghost depthwise separable convolution (see `im2sim.layers.GhostConv`) preset to stem + all encoder blocks in the HalfUNet configuration.
        """
        self.stem_block_cfg.conv_cfg.name = "GhostConv"
        self.stem_block_cfg.conv_cfg.kwargs["separable"] = True
        for e in self.encoder_block_cfg:
            e.conv_cfg.name = "GhostConv"
            e.conv_cfg.kwargs["separable"] = True
        return self

    def add_eca(self):
        """
        Apply an Efficient Channel Attention (ECA) (see `im2sim.layers.EfficientChannelAttn`) preset to all encoder blocks in the HalfUNet configuration.
        """
        for e in self.encoder_block_cfg:
            e.add_eca()

        return self

    def add_se(self):
        """
        Apply a Squeeze-and-Excitation (SE) (see `im2sim.layers.SqueezeExcite`) preset to all encoder blocks in the HalfUNet configuration.
        """
        for e in self.encoder_block_cfg:
            e.add_se()
        return self
