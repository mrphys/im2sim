# ==============================================================================
# Copyright 2026 University College London.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================


class StandardScaler:
    """
    Z-score scaler for node features

    This class can be used to create a z-score/standard scaler for node data.

    Parameters
    ----------
    mean: float, list of floats
        mean of the node feature(s)
    std: float, list of floats
        standard deviation of node feature(s)

    Attributes
    ----------
    mean: float, list of floats
        mean of the node feature(s)
    std: float, list of floats
        standard deviation of node feature(s)
    """


class Normaliser:
    """
    min-max normaliser for node features

    This class can be used to create a 0-1 normaliser for node data.

    Parameters
    ----------
    min: float, list of floats
        min value of the node feature(s)
    max: float, list of floats
        max value of node feature(s)

    Attributes
    ----------
    min: float, list of floats
        min value of the node feature(s)
    max: float, list of floats
        max value of node feature(s)
    """


class DataProcessor:
    """
    Node Data Processor for Im2Sim models

    This class provides the basis for building custom data generators for Im2Sim models.

    Parameters
    ----------
    data_gen: function
        Function that yeilds input-output pairs for each da

    Attributes
    ----------
    attr1 : type
        Description of `attr1`.
    attr2 : type
        Description of `attr2`.

    Examples
    --------
    .. code-block:: python

        obj = MyClass(param1=10, param2="test")
        obj.method()  # 42
    """
