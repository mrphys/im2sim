# ==============================================================================
# Copyright 2026 University College London.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

import torch

from im2sim.configs.core import LayerConfig
from im2sim.configs.image_blocks import ImageConvBlockConfig
from im2sim.utils.layer_util import (
    InvalidBlockConfigError,
    apply_residual_connection,
    get_activation,
    get_image_layer,
)


class ImageConvBlock(torch.nn.Module):
    """
    A configurable image convolutional block that consists of a sequence of
    convolutional layers, normalization layers, dropout layers, and attention
    layers. The block supports residual connections and allows for flexible
    configuration of its components.

    Note:
        `cfg.activation` is applied after every layer, including the last, and `cfg.out_activation`
        is applied to that already-activated output. With e.g. `activation="ReLU"` and
        `out_activation="sigmoid"` the output is therefore limited to `[0.5, 1)`. For an output block
        that should produce unconstrained values or logits, use `activation=None` and put the
        nonlinearity in `out_activation` only (see `ImageConvBlockConfig`).

    Args:
        in_channels (int):
            Number of input channels.

        out_channels (int):
            Number of output channels.

        rank (int):
            The rank of the convolutional layers (e.g., `2` for 2D convolutions).

        cfg (ImageConvBlockConfig):
            Configuration object that defines the parameters of the block.

        temporal (bool):
            If True, the temporal versions of the layers (see `im2sim.layers.temporal_layers`) are used,
            so the block accepts inputs of shape `(N, C, T, *spatial)`. Only supported for rank `2` and `3`
            and the layers in `im2sim.layers.temporal_layers.SUPPORTED_TEMPORAL_LAYERS`; other layers
            raise an `UnsupportedTemporalLayerError`. Default is `False`.

    Examples:

        To create an ImageConvBlock with a depth of 3, ReLU activation, and softmax output activation, you can use the following code:

        .. code-block:: python

            cfg = ImageConvBlockConfig(depth=3, activation="ReLU", out_activation="softmax")
            model = ImageConvBlock(
                rank=2,
                in_channels=32,
                out_channels=32,
                cfg=cfg,
            )

        Since the configs are rankless, you could use the same config for a 1D, 2D, or 3D convolutional block by changing the rank parameter when creating the ImageConvBlock instance.

        .. code-block:: python

            cfg = ImageConvBlockConfig(depth=3, activation="ReLU", out_activation="softmax")
            model1D = ImageConvBlock(
                rank=1,
                in_channels=32,
                out_channels=32,
                cfg=cfg,
            )
            model2D = ImageConvBlock(
                rank=2,
                in_channels=32,
                out_channels=32,
                cfg=cfg,
            )
            model3D = ImageConvBlock(
                rank=3,
                in_channels=32,
                out_channels=32,
                cfg=cfg,
            )

        Models can be saved and loaded using the standard PyTorch methods:

        .. code-block:: python

            torch.save(model.state_dict(), "model.pth")
            model.load_state_dict(torch.load("model.pth"))

        Configs can also be saved and loaded using the methods provided in the `im2sim.configs.ImageConvBlockConfig` class:
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        rank: int,
        cfg: ImageConvBlockConfig,
        temporal: bool = False,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.rank = rank
        self.temporal = temporal
        self.depth = cfg.depth
        # `activation` is the first layer's activation; every layer gets its own instance so that
        # learnable activations (e.g. PReLU) are not shared across layers.
        self._activation_name = cfg.activation
        self.activation = get_activation(cfg.activation)
        self.out_activation = get_activation(cfg.out_activation)
        self.conv_cfg = cfg.conv_cfg
        self.norm_cfg = cfg.norm_cfg
        self.attn_cfg = cfg.attn_cfg
        self.dropout_cfg = cfg.dropout_cfg
        self.dropout_position = (
            cfg.dropout_position
            if isinstance(cfg.dropout_position, list)
            else [cfg.dropout_position]
        )
        self.residual_connections = (
            cfg.residual_connections if cfg.residual_connections is not None else {}
        )
        self.residual_type = cfg.residual_type

        self._set_default_configs()
        self._validate_configs()

        self.layers = torch.nn.ModuleList()
        in_channels_per_layer = []
        in_channels_current = self.in_channels

        for i in range(self.depth):
            if i in self.residual_connections and self.residual_type.lower().strip() == "concat":
                for src in self.residual_connections[i]:
                    in_channels_current += in_channels_per_layer[src]

            in_channels_per_layer.append(in_channels_current)

            conv = get_image_layer(self.conv_cfg.name, rank=self.rank, temporal=self.temporal)(
                in_channels=in_channels_per_layer[-1],
                out_channels=out_channels,
                **self.conv_cfg.kwargs,
            )

            norm = get_image_layer(self.norm_cfg.name, rank=self.rank, temporal=self.temporal)(
                self.out_channels, **self.norm_cfg.kwargs
            )

            dropout = (
                get_image_layer(self.dropout_cfg.name, rank=self.rank, temporal=self.temporal)(
                    **self.dropout_cfg.kwargs
                )
                if (i + 1) in self.dropout_position
                else torch.nn.Identity()
            )

            pre_residual = self.attn_cfg.name is not None and (i + 1) in self.residual_connections
            no_residual_final = len(self.residual_connections.keys()) == 0 and i == self.depth - 1
            if pre_residual or no_residual_final:
                attn = get_image_layer(self.attn_cfg.name, rank=self.rank, temporal=self.temporal)(
                    self.out_channels, **self.attn_cfg.kwargs
                )
            else:
                attn = torch.nn.Identity()

            block = torch.nn.Sequential(
                conv,
                norm,
                dropout,
                attn,
                self.activation if i == 0 else get_activation(self._activation_name),
            )
            self.layers.append(block)

            in_channels_current = self.out_channels

    def _set_default_configs(self):
        if self.conv_cfg is None:
            self.conv_cfg = LayerConfig(name="Conv", kwargs={"kernel_size": 3, "padding": "same"})
        if self.norm_cfg is None:
            self.norm_cfg = LayerConfig(name=None, kwargs={})
        if self.dropout_cfg is None:
            self.dropout_cfg = LayerConfig(name=None, kwargs={})
        if self.attn_cfg is None:
            self.attn_cfg = LayerConfig(name=None, kwargs={})

    def _validate_configs(self):
        if self.norm_cfg.name not in [None, "BatchNorm", "InstanceNorm"]:
            raise InvalidBlockConfigError(f"Unsupported norm type: {self.norm_cfg.name}")
        if self.attn_cfg.name not in [None, "EfficientChannelAttn", "SqueezeExcite"]:
            raise InvalidBlockConfigError(f"Unsupported attention type: {self.attn_cfg.name}")
        if self.dropout_cfg.name is not None and max(self.dropout_position) >= self.depth:
            raise InvalidBlockConfigError("Dropout position must be less than depth")

        if self.residual_type.lower().strip() == "concat" and any(
            dst >= self.depth for dst in self.residual_connections
        ):
            raise ValueError(
                "Residual connections with 'concat' type cannot be created on the last layer since it would change the output channels."
            )

    def forward(self, x):
        """ """
        outputs = [x]
        for i, layer in enumerate(self.layers):
            x = self._check_and_apply_residual(x, i, outputs)
            x = layer(x)
            outputs.append(x)
        x = self._check_and_apply_residual(x, self.depth, outputs)
        x = self.out_activation(x)
        return x

    def _check_and_apply_residual(self, x, i, outputs):
        if i in self.residual_connections:
            # Combine all sources in one call so "average" weights every input equally. Sources
            # are passed last-first to keep the channel order of "concat" unchanged.
            sources = [outputs[src] for src in reversed(self.residual_connections[i])]
            x = apply_residual_connection(*sources, x, connection_type=self.residual_type)
        return x


if __name__ == "__main__":
    block_cfg = ImageConvBlockConfig(
        depth=4,
        activation="LeakyReLU",
        out_activation="sigmoid",
        conv_cfg=LayerConfig(name="Conv", kwargs={"kernel_size": 5, "padding": "same"}),
        norm_cfg=LayerConfig(name="BatchNorm", kwargs={"affine": True}),
        dropout_cfg=LayerConfig(name="Dropout", kwargs={"p": 0.5}),
        attn_cfg=LayerConfig(name="SqueezeExcite", kwargs={}),
        dropout_position=[1, 3],
        residual_connections={3: [0, 1]},
        residual_type="concat",
    )
    mini_block_cfg = block_cfg.mod(depth=2, dropout_position=[1], residual_connections={1: [0]})

    # block_cfg = block_cfg.mod(residual_connections={3: [1, 0]})
    model = ImageConvBlock(
        rank=2,
        in_channels=32,
        out_channels=32,
        cfg=mini_block_cfg,
    )

    print(model)
    x = torch.randn(1, 32, 64, 64)
    y = model(x)
    print(y.shape)
