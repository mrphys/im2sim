# ==============================================================================
# Copyright 2026 University College London.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

import logging

import torch
from torch import nn

logger = logging.getLogger(__name__)


# class TrilinearProjection(nn.Module):
#     def __init__(self, domain_size):
#         super().__init__()
#         self.domain_size = domain_size

#     def forward(self, encoder_outputs, graph_coords, batch):
#         projections = []

#         n_dims = graph_coords.shape[1]
#         for i in torch.unique(batch).to(torch.int16):
#             coords = graph_coords[batch == i]
#             n_nodes = coords.shape[0]

#             grid = torch.stack(
#                 [(2 * coords[:, j] / (d - 1)) - 1 for j, d in enumerate(self.domain_size)],
#                 axis=-1,
#             )  # normalise coords [-1,1] and divide by scale

#             grid = grid.reshape(1, n_nodes, 1, 1, n_dims)  # [N,3]->[1,N,1,1,3]

#             grid = grid.type_as(encoder_outputs)

#             projections.append(
#                 F.grid_sample(
#                     encoder_outputs[i].unsqueeze(0),
#                     grid,
#                     align_corners=True,
#                     padding_mode="border",
#                 )
#                 .reshape(encoder_outputs.shape[1], -1)
#                 .permute(1, 0)
#             )  # [1,C,N,1,1] -> [1,C,N] -> [N,C]

#             projections = torch.cat(projections, dim=0)

#         return projections


class TrilinearProjection(nn.Module):
    """
    TrilinearProjection layer projects image features onto graph coordinates using trilinear interpolation.

    Args:
        image_dim (int):
            The size of each dimension of the image the graph coordinates are defined in (i.e. the full resolution input image).
            The coordinates are scaled by `image_features.shape[-3] / image_dim` to map them onto the image feature map.
    """

    def __init__(self, image_dim):
        super().__init__()
        self.image_dim = image_dim

    def forward(self, image_features, graph):
        """
        Projects image features onto graph coordinates using trilinear interpolation.

        Args:
            image_features (torch.Tensor):
                A tensor of shape [batch_size, channels, height, width, depth] representing the image features.

            graph (pyg.data.Data):
                A PyTorch Geometric Data object containing the graph data.
                It must have 'coords' and 'batch' attributes. Only the first 3 columns of 'coords' are used.

        Returns:
            torch.Tensor: The projected features of shape [num_nodes, channels].
        """
        coords = graph.coords
        batch = graph.batch
        if batch is None:
            batch = torch.zeros(coords.shape[0], dtype=torch.long, device=coords.device)
        if batch.numel() > 0 and int(batch.max()) >= image_features.shape[0]:
            raise ValueError(
                f"The graph has {int(batch.max()) + 1} graphs but image_features has a batch size "
                f"of {image_features.shape[0]}."
            )
        projections = image_features.new_zeros(coords.shape[0], image_features.shape[1])
        for i in torch.unique(batch):
            # TensorFlow tf.shape equivalents
            h = image_features[i].shape[-3]
            w = image_features[i].shape[-2]
            d = image_features[i].shape[-1]

            # First 3 coords
            x = coords[batch == i, 0]
            y = coords[batch == i, 1]
            z = coords[batch == i, 2]

            factor = torch.tensor(self.image_dim / h, dtype=x.dtype, device=x.device)

            x = x / factor
            y = y / factor
            z = z / factor

            # Lower corner is floor(coord) and upper corner is lower + 1, both clamped to the grid.
            # Using ceil for the upper corner would give x1 == x2 for integer coordinates and
            # zero interpolation weights.
            def corners(c, size):
                c = torch.clamp(c, 0, size - 1)
                c1 = torch.floor(c)
                c2 = torch.clamp(c1 + 1, max=size - 1)
                return c, c1, c2

            x, x1, x2 = corners(x, h)
            y, y1, y2 = corners(y, w)
            z, z1, z2 = corners(z, d)

            # interpolation weights (computed before casting the corners to int)
            wx = (x - x1).unsqueeze(0)
            wx2 = 1 - wx
            wy = (y - y1).unsqueeze(0)
            wy2 = 1 - wy
            wz = (z - z1).unsqueeze(0)
            wz2 = 1 - wz

            # cast to int for indexing
            x1 = x1.long()
            x2 = x2.long()
            y1 = y1.long()
            y2 = y2.long()
            z1 = z1.long()
            z2 = z2.long()

            # mimic tf.gather_nd(image_features[0], ...)
            img0 = image_features[i]

            def gather(img, xi, yi, zi):
                return img[..., xi, yi, zi]

            # --- z1 plane ---
            q11 = gather(img0, x1, y1, z1)
            q21 = gather(img0, x2, y1, z1)
            q12 = gather(img0, x1, y2, z1)
            q22 = gather(img0, x2, y2, z1)

            lerp_x1 = q21 * wx + q11 * wx2
            lerp_x2 = q22 * wx + q12 * wx2

            lerp_y1 = lerp_x2 * wy + lerp_x1 * wy2

            # --- z2 plane ---
            q11 = gather(img0, x1, y1, z2)
            q21 = gather(img0, x2, y1, z2)
            q12 = gather(img0, x1, y2, z2)
            q22 = gather(img0, x2, y2, z2)

            lerp_x1 = q21 * wx + q11 * wx2
            lerp_x2 = q22 * wx + q12 * wx2

            lerp_y2 = lerp_x2 * wy + lerp_x1 * wy2

            # --- z interpolation ---
            lerp_z = lerp_y2 * wz + lerp_y1 * wz2
            # [C, N_i] -> [N_i, C], written back to this graph's nodes
            projections[batch == i] = lerp_z.permute(1, 0)

        return projections
